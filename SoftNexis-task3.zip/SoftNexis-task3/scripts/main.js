const body = document.body;
const themeToggle = document.getElementById('theme-toggle');
const filterStatus = document.getElementById('filter-status');
const contactForm = document.getElementById('contact-form');
const modal = document.getElementById('info-modal');
const openModalButton = document.getElementById('info-btn');
const closeModalButton = document.getElementById('close-modal');

let lastFocusedElement = null;

function showUserMessage(element, message) {
  element.textContent = message;
}

function setTheme(isDark) {
  body.classList.toggle('dark-theme', isDark);
  themeToggle.setAttribute('aria-pressed', String(isDark));
  themeToggle.textContent = isDark ? 'Light mode' : 'Dark mode';
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

function initializeTheme() {
  try {
    const savedTheme = localStorage.getItem('theme');
    setTheme(savedTheme === 'dark');
  } catch (error) {
    console.error('Theme preference could not be loaded:', error);
  }
}

function handleThemeToggle() {
  const isDark = !body.classList.contains('dark-theme');
  setTheme(isDark);
  console.log('Theme changed:', isDark ? 'dark' : 'light');
}

function updateFilterButtons(activeButton) {
  document.querySelectorAll('.filter-button').forEach((button) => {
    const isActive = button === activeButton;
    button.classList.toggle('active', isActive);
    button.setAttribute('aria-pressed', String(isActive));
  });
}

function filterMenuItems(category) {
  const menuItems = document.querySelectorAll('[data-category]');
  let visibleCount = 0;

  menuItems.forEach((item) => {
    const shouldShow = category === 'all' || item.dataset.category === category;
    item.classList.toggle('is-hidden', !shouldShow);
    if (shouldShow) {
      visibleCount += 1;
    }
  });

  showUserMessage(filterStatus, `${visibleCount} menu items shown.`);
  console.table({ category, visibleCount });
}

function validateEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function setFieldError(fieldId, message) {
  const field = document.getElementById(fieldId);
  const error = document.getElementById(`${fieldId}-error`);
  error.textContent = message;
  field.setAttribute('aria-invalid', message ? 'true' : 'false');
}

function validateForm() {
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  let isValid = true;

  setFieldError('name', '');
  setFieldError('email', '');
  setFieldError('message', '');

  if (name.length < 2) {
    setFieldError('name', 'Please enter at least 2 characters.');
    isValid = false;
  }

  if (!validateEmail(email)) {
    setFieldError('email', 'Please enter a valid email address.');
    isValid = false;
  }

  if (message.length < 10) {
    setFieldError('message', 'Please enter a message of at least 10 characters.');
    isValid = false;
  }

  return isValid;
}

function createConfirmationNote() {
  const existingNote = document.getElementById('confirmation-note');

  if (existingNote) {
    existingNote.remove();
  }

  const note = document.createElement('p');
  note.id = 'confirmation-note';
  note.className = 'confirmation-note';
  note.textContent = 'A staff member will reply within one business day.';
  contactForm.appendChild(note);
}

function handleFormSubmit(event) {
  event.preventDefault();

  try {
    if (!validateForm()) {
      showUserMessage(document.getElementById('form-status'), 'Please fix the highlighted fields.');
      const firstInvalid = contactForm.querySelector('[aria-invalid="true"]');
      firstInvalid.focus();
      return;
    }

    showUserMessage(document.getElementById('form-status'), 'Thanks. Your message is ready to send.');
    createConfirmationNote();
    contactForm.reset();
    console.log('Contact form validated successfully.');
  } catch (error) {
    console.error('Form validation failed:', error);
    showUserMessage(document.getElementById('form-status'), 'Something went wrong. Please try again.');
  }
}

function openModal() {
  lastFocusedElement = document.activeElement;
  modal.setAttribute('aria-hidden', 'false');
  body.classList.add('modal-open');
  closeModalButton.focus();
}

function closeModal() {
  modal.setAttribute('aria-hidden', 'true');
  body.classList.remove('modal-open');
  if (lastFocusedElement) {
    lastFocusedElement.focus();
  }
}

function handleModalKeydown(event) {
  if (event.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
    closeModal();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initializeTheme();
  themeToggle.addEventListener('click', handleThemeToggle);
  contactForm.addEventListener('submit', handleFormSubmit);
  openModalButton.addEventListener('click', openModal);
  closeModalButton.addEventListener('click', closeModal);
  document.addEventListener('keydown', handleModalKeydown);

  document.querySelector('.filter-controls').addEventListener('click', (event) => {
    const button = event.target.closest('.filter-button');
    if (!button) {
      return;
    }

    updateFilterButtons(button);
    filterMenuItems(button.dataset.filter);
  });
});
